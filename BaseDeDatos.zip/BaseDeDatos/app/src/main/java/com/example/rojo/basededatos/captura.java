package com.example.rojo.basededatos;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class captura extends AppCompatActivity {

    DatosBase db;

    private EditText editName;
    private EditText editSecond;
    private Button btnSave;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captura);

        db = new DatosBase(this);

        editName = (EditText) findViewById(R.id.txtIngresoA);
        editSecond = (EditText) findViewById(R.id.txtIngresoB);
        btnSave=(Button)findViewById(R.id.btnCaptura);
    }


    public void Guardar(View v){
        db.insert(editName.getText().toString(),editSecond.getText().toString());
        Toast.makeText(this, "Se Guardo Correctamente", Toast.LENGTH_SHORT).show();
        editName.setText("");
        editSecond.setText("");
    }

}
