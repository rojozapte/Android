package com.example.rojo.basededatos;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;



public class borrado extends AppCompatActivity {

    private EditText borrar;
    private Button bt;
    ListView lista;


    DatosBase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrado);

        borrar=(EditText) findViewById(R.id.txtBuscar);
        lista=(ListView)findViewById(R.id.Datos);
        bt=(Button)findViewById(R.id.btnBorrar);
    }


    public void buscarFuncion(View v){
        ArrayList<String> data = new ArrayList<>();
        ArrayAdapter adaptador;
        Cursor c;

        db= new DatosBase(this);

        c = db.search(borrar.getText().toString());
        if (c.moveToFirst()){
            do {
                data.add(c.getString(0));
            }while(c.moveToNext());

            adaptador=new ArrayAdapter(this,android.R.layout.simple_list_item_1, data);
            lista.setAdapter(adaptador);

            if (!data.isEmpty()) {
                bt.setEnabled(true);
            }

        }

    }

    public void borrarFuncion(View v){
        db=new DatosBase(this);
        db.delete(borrar.getText().toString());
        finish();
    }


}
