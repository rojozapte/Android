package com.example.rojo.basededatos;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by ALUMNO on 15/02/2019.
 */

public class DatosBase {
    private SQLiteDatabase db;

    public static final String TABLE_ROW_NOMBRE = "Nombre";
    public static final String TABLE_ROW_APELLIDO = "Apellido";

    private static final String DB_NAME = "CursoAndroid";
    private static final int DB_VERSION = 1;
    private  static final String TABLE_NAME = "Datos";

    public DatosBase(Context context){
        MyCustomSQLiteOpenHelper helper = new MyCustomSQLiteOpenHelper(context);
        db = helper.getWritableDatabase();
    }

    public void insert(String nombre,String apellido){
        /*
        *INSTER INTO NAME_TABLE (name) VALUES ('name');
         **/
        String query = "INSERT INTO " + TABLE_NAME +
                " (" + TABLE_ROW_NOMBRE + ", "+TABLE_ROW_APELLIDO+") VALUES ('"+nombre+"','"+apellido+"');";
        Log.i("insert()", query);
        db.execSQL(query);
    }

    public void delete(String name){
        /**
         * DELETE FROM TABLR_NAME WHERE name = 'name';
         */
        String querydelete = "DELETE FROM " + TABLE_NAME +
                " WHERE " + TABLE_ROW_NOMBRE + " = " +
                "'" + name + "';";
        Log.i("delete()", querydelete);
        db.execSQL(querydelete);
    }

    public Cursor search(String name){
        /**
         * SELECT NAME_ROW FROM TABLe_NAME WHERE NAME_ROW = 'name';
         */
        String querysarch = "SELECT " + TABLE_ROW_NOMBRE + " FROM " +
                TABLE_NAME + " WHERE " + TABLE_ROW_NOMBRE +
                " = '" + name + "';";
        Log.i("search()", querysarch);
        Cursor c = db.rawQuery(querysarch, null);
        return c;
    }



    public Cursor searchAll(){
        /**
         * SELECT * FROM TABLe_NAME;
         */
        String queryAll = "SELECT * FROM " +
                TABLE_NAME + ";";

        Log.i("searchAll()", queryAll);
        Cursor c = db.rawQuery(queryAll, null);
        return c;
    }


    private  class MyCustomSQLiteOpenHelper extends SQLiteOpenHelper{

        public MyCustomSQLiteOpenHelper(Context context){
            super(context, DB_NAME, null, DB_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db){

            String newTableQuery = "CREATE TABLE " +
                    TABLE_NAME + " (" +
                    TABLE_ROW_NOMBRE + " TEXT NOT NULL, " +
                    TABLE_ROW_APELLIDO + " TEXT NOT NULL);";
            db.execSQL(newTableQuery);

        }
        @Override
        public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion){

        }
    }

}